import math

_SCHEMA_FAMILY_TAG = 'liebig_min_2d'
_CORE_LAW_EXPR = "min(2.049983654 * f['vcpu_cores'], 2.450807419 * f['iops_k'])"
_LENS = {'sign': 1.0, 'scale': 1.0, 'offset': 0.0}

def fit(observations):
    return None

def predict(row):
    f = row['features']
    latent = min(2.049983654 * f['vcpu_cores'], 2.450807419 * f['iops_k'])
    return 0 + (1) * (1) * latent
