# V16.9 Audited Failure Cases, Small-Bank Tradeoffs & Attribution Boundaries (`failure_cases.md`)

## 1. 小规模候选库（7 源样本）下 `Hegel_M2` 对全历史 `O_strong_AllValidatedPriors` 的诚实权衡
- 放开 `O_strong` 保留同维全部有效历史候选（含单源及近失例）并采用对称 5 点/6 点 pilot 后，两臂在目标期物理测量费打平（`ΔMeas = +0.0000`，均为 `340.0`/簇），而 `Hegel_M2` 因条件定向召回免除同维多 schema 遍历，目标期逻辑计算节省 `ΔCompute = -179.0000`（默认 `λ=0.05` 下目标期净省 `-8.9500`，`4/4` 簇全负）。
- 同时，由于 `Hegel_M2` 在源期执行了旧模型反例核验与尺度探针（源期多投 `+15.0`/簇），单批 10 道目标的端到端差额为 `+6.0500`（目标流延展至约 17 道同分布未见目标后摊回源期多投；若计入一次性 DEV 门控校准 `1994.7`，则需更长目标流或共用开发设施）。

## 2. 库外函数（`5 + sin(u)`）诚实退出与前缀隔离确认
- 在有限十类语法外的新规律 `y = 5 + sin(u)` 上，新点确认失败后返回 `status='scoped_unknown'`（绝不再伪造 `completed`），`false_confirmation = False`；有状态 `memorize.py` 在前缀冻结下确认 `RMSE = 9.0` 被拦截。

## 3. 横边局部消融与扁平同元数据对照的精确归因
- 允许跨领域直接读取 local 节点但关闭横边（`NoWhAllowLocal`）在小规模 7 节点无干扰碰撞库中差额为 `+0.0000`（完整关闭跨领域迁移差额为 `-120.3250`）：如实证明小库无干扰碰撞时 local 内容本身即可命中，而横边排除条件与图检索结构专为 **M3 大规模异质干扰森林（K>=32）** 保留。
- 相对同门控传递簇 `Flat_TransitiveCluster` 差额为 `-17.4375`（实测两跳非传递误差界拦截无效尝试），相对保存完整路径界与同门控的 `Flat_EqualMetadata_PathAware` 差额为 `-1.0125`（仅线性表扫描开销差）。
