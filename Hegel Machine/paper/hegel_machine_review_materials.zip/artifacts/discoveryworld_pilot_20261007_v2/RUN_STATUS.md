# DiscoveryWorld development pilot

Four registered runs: Reactor Lab Normal and Challenge, seed 0, Code archive and Hegel. Two processes execute the runs; queued runs start when a slot finishes. Model: requested gpt-6-luna, medium, ChatGPT subscription. Limits are in protocol.json: 2,000 environment steps, 2,000 model calls, 8 hours per episode, 900 seconds per request; no aggregate token cutoff. Cache usage is recorded per call.

See summary.json for terminal results and <task>/<arm>/active.json for current progress. Full public observations and authored programs are under each arm’s agent/ directory. This development pilot is not the complete 16-task development panel or the 64-task held-out experiment.

The earlier ../discoveryworld_pilot_20261007/ attempt is preserved as an interrupted interface diagnostic: intermediate batch measurements were missing from the next-call preview. Both arms now receive per-action messages; 5 targeted tests passed before this restart.
