"""Shared request compaction for code decision providers."""

from copy import deepcopy
import json
from pathlib import Path


def prepare_code_context(workspace, request, *, schema, instructions):
    """Persist the full request and return the compact provider-facing copy."""
    workspace = Path(workspace)
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "research_context.json").write_text(json.dumps(request), encoding="utf-8")
    (workspace / "code_action_schema.json").write_text(json.dumps(schema), encoding="utf-8")
    (workspace / "code_agent_instructions.txt").write_text(instructions, encoding="utf-8")
    context = deepcopy(request)
    observations = context.get("observations", [])
    offset = max(0, len(observations) - 12)
    context["observations"] = [{**row, "row_index": offset + index}
                                for index, row in enumerate(observations[offset:])]
    context["evidence"] = {"observations_file": "observations.json", "observation_count": len(observations),
                            "preview_start": offset, "full_context_file": "research_context.json"}
    events = context.get("events", [])
    for index, event in enumerate(events):
        arguments = event.get("arguments", {})
        compact_arguments = {key: value for key, value in arguments.items()
                             if key not in ("sequence", "code")}
        if "sequence" in arguments:
            compact_arguments["sequence_rows"] = len(arguments["sequence"])
        if "code" in arguments:
            compact_arguments["path"] = arguments.get("path", f"scratch_{index:03d}.py")
        feedback = event.get("feedback", {})
        if index < len(events) - 1:
            feedback = {key: value for key, value in feedback.items()
                        if key not in ("stdout", "stderr")}
        events[index] = {key: value for key, value in event.items()
                         if key not in ("arguments", "feedback", "usage")}
        events[index].update(arguments=compact_arguments, feedback=feedback)
    knowledge = context.get("session_knowledge", {})
    if "files" in knowledge:
        knowledge["shared_files"] = list(knowledge["files"])
        knowledge["files"] = {name: code for name, code in knowledge["files"].items()
                               if context.get("files", {}).get(name) != code}
    return context
