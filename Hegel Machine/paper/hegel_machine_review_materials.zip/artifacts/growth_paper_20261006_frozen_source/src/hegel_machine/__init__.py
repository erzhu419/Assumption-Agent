"""Hegel Machine: hypothesis discovery, active experiments and revisable knowledge."""

import sys as _sys


_FORMAL_M3_DIRECT_ONLY_MODULES = {
    "hegel_machine.phase3_m3_start_cli_v1",
    "hegel_machine.phase3_m3_formal_execution_cli_v1",
}
try:
    _module_switch = _sys.orig_argv.index("-m")
except ValueError:
    _module_switch = -1
if (
    _module_switch >= 0
    and len(_sys.orig_argv) > _module_switch + 1
    and _sys.orig_argv[_module_switch + 1] in _FORMAL_M3_DIRECT_ONLY_MODULES
):
    raise RuntimeError(
        "formal M3 commands require their committed direct entrypoints"
    )

from .milestones import PHASE2A, PHASE2B, PHASE2R, PHASE3A, PHASE3B, PHASE3C
from .phase2b_selector import (
    CandidateEvaluation,
    CandidateGridCommitment,
    CandidateGridCell,
    TypedSelectorDecision,
    select_typed_candidate_evaluations,
)
from .phase2b_wire import PredictionBundle, PublicEvidenceBundle
from .phase2b_freeze_v1 import (
    Phase2BExactFreeze,
    frozen_phase2b_exact_freeze,
)
from .phase3_certificate_v1 import OutsideFrozenClosureClaim
from .phase3_closure_preflight import phase3_closure_capacity_preflight_report
from .phase3_dsl_v1 import (
    OBSERVED_OMITTED_SINK_CONTROL,
    ODD_REDUCTION_TARGET,
    OLD_DSL_V1,
)
from .phase3_strict_replay_v1 import (
    dual_capacity_replay_report,
    dual_strict_gate_report,
)
from .phase3_shrink1_publication_v1 import shrink1_publication_report
from .phase3_shrink1_replay_v1 import (
    dual_shrink1_capacity_replay_report,
    dual_shrink1_strict_gate_report,
)
from .strict_ast_shrink1_v1 import (
    canonicalize_shrink1_source_ast,
    decode_shrink1_canonical_ast,
)
from .strict_ast_v1 import CanonicalAst, canonicalize_source_ast, decode_canonical_ast

from .recognition import (
    RecognitionDecision,
    RecognitionDisposition,
    RecognitionPolicy,
    StructuralProjection,
    UnboundStructuralEpisode,
    recognize_structural_law,
    replay_recognition_decision,
)

from .schema import (
    EvidenceReceipt,
    LawKind,
    RelationLaw,
    TheoryPatch,
    TheoryState,
)

from .cognition.controller import CognitiveAgent
from .cognition.memory import KnowledgeLibrary
from .cognition.models import ResearchConfig

__all__ = [
    "CognitiveAgent",
    "KnowledgeLibrary",
    "ResearchConfig",
    "EvidenceReceipt",
    "LawKind",
    "PHASE2A",
    "PHASE2B",
    "PHASE2R",
    "PHASE3A",
    "PHASE3B",
    "PHASE3C",
    "Phase2BExactFreeze",
    "PredictionBundle",
    "PublicEvidenceBundle",
    "OLD_DSL_V1",
    "ODD_REDUCTION_TARGET",
    "OBSERVED_OMITTED_SINK_CONTROL",
    "OutsideFrozenClosureClaim",
    "RecognitionDecision",
    "RecognitionDisposition",
    "RecognitionPolicy",
    "RelationLaw",
    "StructuralProjection",
    "TheoryPatch",
    "TheoryState",
    "TypedSelectorDecision",
    "UnboundStructuralEpisode",
    "CandidateEvaluation",
    "CandidateGridCommitment",
    "CandidateGridCell",
    "CanonicalAst",
    "canonicalize_source_ast",
    "decode_canonical_ast",
    "dual_capacity_replay_report",
    "dual_strict_gate_report",
    "dual_shrink1_capacity_replay_report",
    "dual_shrink1_strict_gate_report",
    "canonicalize_shrink1_source_ast",
    "decode_shrink1_canonical_ast",
    "recognize_structural_law",
    "replay_recognition_decision",
    "select_typed_candidate_evaluations",
    "frozen_phase2b_exact_freeze",
    "phase3_closure_capacity_preflight_report",
    "shrink1_publication_report",
]

__version__ = "0.181.0"
