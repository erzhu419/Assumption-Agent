import numpy as np
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

_METER = np.array([0.7351297000480436, 0.994562815446184, -0.32172587344499515])
_MEAN = np.array([0.518924853976035, 0.5044797274906009, 0.22031250000000005, 0.2208333333333334])
_SCALE = np.array([0.9053053018202591, 0.886149049743353, 0.6753694253348187, 0.6622510014253575])
_COEF = np.array([0.4201904722526688, 0.7683576288695637, 0.676568279296683, 0.34504268618861156, -0.10839070728917016, 0.4458937720202303, 0.2854017007510508, 0.2907391867437891, -0.10541823047068781, 0.11880379907095745, 0.24754560255231894, -0.06902674138937537, 0.12893597978780355, -0.07200693249558494, 0.009867584060975302])
_POLY = PolynomialFeatures(degree=2, include_bias=True)


def predict(row):
    controls = [float(v['u']) for v in row.get('history', [])]
    controls.append(float(row['features']['u']))
    meter_prev = 0.0
    control_prev = 0.0
    output = 0.0
    for control in controls:
        meter = float(_METER @ np.array([meter_prev, control, control_prev]))
        x = (np.array([[meter, meter_prev, control, control_prev]]) - _MEAN) / _SCALE
        output = float(_POLY.fit_transform(x)[0] @ _COEF)
        meter_prev, control_prev = meter, control
    return output