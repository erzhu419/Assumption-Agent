"""Host-side isolation contract for an untrusted Phase-2B recognizer.

The functions here build and audit an OCI launch specification; they do not
pretend that constructing an argv tuple proves the container was actually run
with those controls.  A formal run additionally needs an external runtime
attestation and the one-shot custodian ledger in :mod:`phase2b_protocol`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
import re
from typing import Final

from .hashing import stable_hash
from .phase2b_freeze_v1 import frozen_phase2b_exact_freeze
from .phase2b_protocol import ExecutionFreezeManifest, frozen_phase2b_protocol


RECOGNIZER_INPUT_MOUNT: Final = "/phase2b/input"
RECOGNIZER_OUTPUT_MOUNT: Final = "/phase2b/output"
RECOGNIZER_TMP_MOUNT: Final = "/tmp"
RECOGNIZER_RUNTIME_UID_GID: Final = "65534:65534"
RECOGNIZER_SECCOMP_PROFILE_RELATIVE_PATH: Final = (
    "config/phase3_internal_actor_seccomp_v1.json"
)
RECOGNIZER_SECCOMP_PROFILE_SHA256: Final = (
    "d1284e4731683b73352ecdd1577704ea87aa0b5c582b7b00757c3db4d2c950ca"
)
FROZEN_RECOGNIZER_ENTRYPOINT: Final = (
    "/opt/hegel/bin/phase2b-recognizer",
    "--input",
    RECOGNIZER_INPUT_MOUNT,
    "--output",
    RECOGNIZER_OUTPUT_MOUNT,
)

REQUIRED_RECOGNIZER_MODULES: Final = frozenset(
    {
        "hegel_machine.bootstrap",
        "hegel_machine.hashing",
        "hegel_machine.laws",
        "hegel_machine.milestones",
        "hegel_machine.ontology",
        "hegel_machine.phase2b_adapter",
        "hegel_machine.phase2b_exact_bridge_v1",
        "hegel_machine.phase2b_exact_derived_witness_bridge_v1",
        "hegel_machine.phase2b_exact_transform_semantics_v1",
        "hegel_machine.phase2b_freeze_v1",
        "hegel_machine.phase2b_protocol",
        "hegel_machine.phase2b_recognizer_input_archive_v2",
        "hegel_machine.phase2b_recognizer_prediction_archive_v2",
        "hegel_machine.phase2b_recognizer_prediction_v2",
        "hegel_machine.phase2b_recognizer_runtime_cli_v2",
        "hegel_machine.phase2b_runner",
        "hegel_machine.phase2b_trusted_wire_batch_v1",
        "hegel_machine.phase2b_trusted_wire_batch_v2",
        "hegel_machine.phase2b_trusted_wire_typed_authority_v1",
        "hegel_machine.phase2b_trusted_wire_typed_authority_v2",
        "hegel_machine.phase2b_trusted_wire_typed_replay_v2",
        "hegel_machine.phase2b_trusted_wire_v1",
        "hegel_machine.phase2b_uncertainty_compiler",
        "hegel_machine.phase2b_wire",
        "hegel_machine.phase3_dsl_v1",
        "hegel_machine.schema",
    }
)
FORBIDDEN_RECOGNIZER_MODULE_PREFIXES: Final = (
    "hegel_machine.benchmark",
    "hegel_machine.phase2_exit",
    "hegel_machine.phase2b_actual_unsealed_960",
    "hegel_machine.phase2b_covert_audit",
    "hegel_machine.phase2b_custodian",
    "hegel_machine.phase2b_evaluator",
    "hegel_machine.phase2b_formal_unsealed_prediction_scoring",
    "hegel_machine.phase2b_strict_recognizer_cli",
    "hegel_machine.phase2b_unsealed_960",
    "hegel_machine.phase2b_unsealed_960_prediction_scoring_mechanics_v2",
    "hegel_machine.phase2b_unsealed_prediction_evaluator",
    "hegel_machine.phase3_capacity_witness",
    "hegel_machine.phase3_certificate",
    "hegel_machine.phase3_closure_preflight",
    "hegel_machine.phase3_m3",
    "hegel_machine.phase3_shrink1",
    "hegel_machine.phase3_strict_replay",
    "hegel_machine.recognition",
    "hegel_machine.strict_ast",
    "hegel_machine.strict_cbor",
    "hegel_machine.vertical_slice",
)

# The recognizer receives one split-blind archive containing both frozen
# cohorts.  Only the derived total is public here; the component counts remain
# host-internal and are never placed in the recognizer run specification.
_RUNNER_EXACT_FREEZE: Final = frozen_phase2b_exact_freeze()
_MAIN_RECOGNIZER_CASE_COUNT: Final = (
    _RUNNER_EXACT_FREEZE.holdout.independent_latent_case_count
)
_CHALLENGE_RECOGNIZER_CASE_COUNT: Final = (
    _RUNNER_EXACT_FREEZE.semantic_conflict.case_count
)
if (
    type(_MAIN_RECOGNIZER_CASE_COUNT) is not int
    or _MAIN_RECOGNIZER_CASE_COUNT != 720
    or type(_CHALLENGE_RECOGNIZER_CASE_COUNT) is not int
    or _CHALLENGE_RECOGNIZER_CASE_COUNT != 240
):
    raise RuntimeError("recognizer case-count exact-freeze drift")
TOTAL_RECOGNIZER_CASE_COUNT: Final = (
    _MAIN_RECOGNIZER_CASE_COUNT + _CHALLENGE_RECOGNIZER_CASE_COUNT
)
if TOTAL_RECOGNIZER_CASE_COUNT != 960:
    raise RuntimeError("recognizer total case-count drift")


def _require_sha256(value: str, name: str) -> None:
    if re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError(f"{name} must be a lowercase SHA-256")


def _require_digest(value: str, name: str) -> None:
    if re.fullmatch(r"sha256:[0-9a-f]{64}", value) is None:
        raise ValueError(f"{name} must use sha256:<digest>")


def _absolute_clean_path(value: str, name: str) -> str:
    path = PurePosixPath(value)
    if (
        not path.is_absolute()
        or ".." in path.parts
        or str(path) == "/"
        or str(path) != value
    ):
        raise ValueError(f"{name} must be a specific absolute path")
    return str(path)


@dataclass(frozen=True, slots=True)
class RuntimeLimits:
    cpus: str = "2.0"
    memory: str = "2g"
    pids: int = 128
    timeout_seconds: int = 3600
    tmpfs_bytes: int = 268_435_456
    maximum_output_bytes: int = 536_870_912

    def __post_init__(self) -> None:
        expected = {
            "cpus": "2.0",
            "memory": "2g",
            "pids": 128,
            "timeout_seconds": 3600,
            "tmpfs_bytes": 268_435_456,
            "maximum_output_bytes": 536_870_912,
        }
        for name, frozen_value in expected.items():
            value = getattr(self, name)
            if type(value) is not type(frozen_value) or value != frozen_value:
                raise ValueError(f"{name} differs from the frozen recognizer limit")


@dataclass(frozen=True, slots=True)
class OciRecognizerRunSpec:
    freeze_manifest_id: str
    protocol_id: str
    image_digest: str
    input_host_directory: str
    output_host_directory: str
    repository_host_directory: str
    seccomp_profile_host_path: str
    seccomp_profile_sha256: str
    input_manifest_sha256: str
    expected_case_count: int
    entrypoint: tuple[str, ...]
    limits: RuntimeLimits = RuntimeLimits()

    def __post_init__(self) -> None:
        if not self.freeze_manifest_id or not self.protocol_id:
            raise ValueError("run spec must bind freeze and protocol manifests")
        if self.protocol_id != frozen_phase2b_protocol().protocol_id:
            raise ValueError("run spec protocol drift")
        _require_digest(self.image_digest, "recognizer image digest")
        _require_sha256(self.input_manifest_sha256, "input manifest SHA-256")
        input_path = _absolute_clean_path(
            self.input_host_directory,
            "input host directory",
        )
        output_path = _absolute_clean_path(
            self.output_host_directory,
            "output host directory",
        )
        repository_path = _absolute_clean_path(
            self.repository_host_directory,
            "repository host directory",
        )
        seccomp_path = _absolute_clean_path(
            self.seccomp_profile_host_path,
            "seccomp profile host path",
        )
        if len({input_path, output_path, repository_path}) != 3:
            raise ValueError("input, output, and repository paths must be distinct")
        if _is_within(input_path, repository_path) or _is_within(
            output_path,
            repository_path,
        ):
            raise ValueError("formal run directories must be outside the repository")
        if _is_within(input_path, output_path) or _is_within(output_path, input_path):
            raise ValueError("formal input and output directories cannot overlap")
        expected_seccomp_path = str(
            PurePosixPath(repository_path)
            / RECOGNIZER_SECCOMP_PROFILE_RELATIVE_PATH
        )
        if (
            seccomp_path != expected_seccomp_path
            or self.seccomp_profile_sha256 != RECOGNIZER_SECCOMP_PROFILE_SHA256
        ):
            raise ValueError("recognizer seccomp profile binding drift")
        if (
            type(self.expected_case_count) is not int
            or self.expected_case_count != TOTAL_RECOGNIZER_CASE_COUNT
        ):
            raise ValueError("recognizer run requires exactly 960 split-blind cases")
        if not isinstance(self.entrypoint, tuple) or not self.entrypoint:
            raise TypeError("recognizer entrypoint must be a nonempty tuple")
        if any(not isinstance(item, str) or not item for item in self.entrypoint):
            raise TypeError("recognizer entrypoint items must be nonempty strings")
        if any(
            "answer" in item.casefold()
            or "generator" in item.casefold()
            or "custodian" in item.casefold()
            for item in self.entrypoint
        ):
            raise ValueError("recognizer entrypoint references a forbidden component")
        if self.entrypoint != FROZEN_RECOGNIZER_ENTRYPOINT:
            raise ValueError("recognizer entrypoint differs from the frozen contract")

    @property
    def run_spec_id(self) -> str:
        return stable_hash(self, prefix="phase2b_oci_run_spec_")

    def argv(self, runtime: str) -> tuple[str, ...]:
        """Return the exact owner-accepted local Docker launch vector."""

        if runtime != "/usr/bin/docker":
            raise ValueError("runtime must be the exact /usr/bin/docker executable")
        return (
            runtime,
            "--host=unix:///var/run/docker.sock",
            "run",
            "--rm",
            "--no-healthcheck",
            "--pull=never",
            "--network=none",
            "--ipc=none",
            "--read-only",
            f"--user={RECOGNIZER_RUNTIME_UID_GID}",
            "--cap-drop=ALL",
            "--security-opt=no-new-privileges:true",
            f"--security-opt=seccomp={self.seccomp_profile_host_path}",
            f"--entrypoint={self.entrypoint[0]}",
            f"--cpus={self.limits.cpus}",
            f"--memory={self.limits.memory}",
            f"--pids-limit={self.limits.pids}",
            f"--memory-swap={self.limits.memory}",
            "--ulimit=nofile=256:256",
            "--env=PYTHONHASHSEED=0",
            "--env=PYTHONDONTWRITEBYTECODE=1",
            "--env=PYTHONPATH=/opt/hegel/src",
            "--env=HOME=/nonexistent",
            "--env=NO_PROXY=*",
            (
                f"--tmpfs={RECOGNIZER_TMP_MOUNT}:rw,noexec,nosuid,nodev,"
                f"size={self.limits.tmpfs_bytes}"
            ),
            (
                "--mount=type=bind,src="
                f"{self.input_host_directory},dst={RECOGNIZER_INPUT_MOUNT},readonly"
            ),
            (
                "--mount=type=bind,src="
                f"{self.output_host_directory},dst={RECOGNIZER_OUTPUT_MOUNT}"
            ),
            self.image_digest,
            *self.entrypoint[1:],
        )


def _is_within(candidate: str, parent: str) -> bool:
    candidate_parts = PurePosixPath(candidate).parts
    parent_parts = PurePosixPath(parent).parts
    return candidate_parts[: len(parent_parts)] == parent_parts


def build_oci_run_spec(
    *,
    freeze_manifest: ExecutionFreezeManifest,
    input_host_directory: str,
    output_host_directory: str,
    repository_host_directory: str,
    input_manifest_sha256: str,
    limits: RuntimeLimits = RuntimeLimits(),
) -> OciRecognizerRunSpec:
    return OciRecognizerRunSpec(
        freeze_manifest_id=freeze_manifest.manifest_id,
        protocol_id=freeze_manifest.protocol_id,
        image_digest=freeze_manifest.recognizer_image_digest,
        input_host_directory=input_host_directory,
        output_host_directory=output_host_directory,
        repository_host_directory=repository_host_directory,
        seccomp_profile_host_path=str(
            PurePosixPath(repository_host_directory)
            / RECOGNIZER_SECCOMP_PROFILE_RELATIVE_PATH
        ),
        seccomp_profile_sha256=RECOGNIZER_SECCOMP_PROFILE_SHA256,
        input_manifest_sha256=input_manifest_sha256,
        expected_case_count=TOTAL_RECOGNIZER_CASE_COUNT,
        entrypoint=FROZEN_RECOGNIZER_ENTRYPOINT,
        limits=limits,
    )


@dataclass(frozen=True, slots=True)
class ImageInventoryAudit:
    installed_modules: tuple[str, ...]
    missing_required_modules: tuple[str, ...]
    forbidden_modules_present: tuple[str, ...]
    unexpected_modules_present: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return (
            not self.missing_required_modules
            and not self.forbidden_modules_present
            and not self.unexpected_modules_present
        )


def audit_recognizer_image_modules(
    installed_modules: tuple[str, ...],
) -> ImageInventoryAudit:
    if not isinstance(installed_modules, tuple):
        raise TypeError("installed module inventory must be an immutable tuple")
    if any(not isinstance(item, str) or not item for item in installed_modules):
        raise TypeError("installed module inventory contains an invalid name")
    if len(set(installed_modules)) != len(installed_modules):
        raise ValueError("installed module inventory repeats a module")
    installed = set(installed_modules)
    forbidden = tuple(
        sorted(
            item
            for item in installed
            if any(
                item == prefix or item.startswith(prefix + ".")
                for prefix in FORBIDDEN_RECOGNIZER_MODULE_PREFIXES
            )
        )
    )
    missing = tuple(sorted(REQUIRED_RECOGNIZER_MODULES - installed))
    unexpected = tuple(sorted(installed - REQUIRED_RECOGNIZER_MODULES))
    return ImageInventoryAudit(
        tuple(sorted(installed)),
        missing,
        forbidden,
        unexpected,
    )


@dataclass(frozen=True, slots=True)
class ExternalRuntimeAttestation:
    run_spec_id: str
    runtime_name: str
    runtime_version: str
    external_attestor_id: str
    detached_attestation_sha256: str
    prediction_archive_sha256: str
    audit_archive_sha256: str
    freeze_manifest_id: str
    protocol_id: str
    input_manifest_sha256: str
    prediction_case_count: int
    exit_code: int
    timed_out: bool
    output_size_bytes: int
    observed_network_disabled: bool
    observed_read_only_root: bool
    observed_repository_absent: bool
    observed_answer_manifest_absent: bool

    def __post_init__(self) -> None:
        if not all(
            (
                self.run_spec_id,
                self.runtime_name,
                self.runtime_version,
                self.external_attestor_id,
            )
        ):
            raise ValueError("runtime attestation identity is incomplete")
        for name in (
            "detached_attestation_sha256",
            "prediction_archive_sha256",
            "audit_archive_sha256",
            "input_manifest_sha256",
        ):
            _require_sha256(getattr(self, name), name)
        if isinstance(self.exit_code, bool) or not isinstance(self.exit_code, int):
            raise TypeError("runtime exit code must be an integer")
        if (
            isinstance(self.output_size_bytes, bool)
            or not isinstance(self.output_size_bytes, int)
            or self.output_size_bytes < 0
        ):
            raise ValueError("runtime output size must be nonnegative")
        if (
            type(self.prediction_case_count) is not int
            or self.prediction_case_count < 0
        ):
            raise ValueError("prediction case count must be a nonnegative integer")
        for name in (
            "timed_out",
            "observed_network_disabled",
            "observed_read_only_root",
            "observed_repository_absent",
            "observed_answer_manifest_absent",
        ):
            if type(getattr(self, name)) is not bool:
                raise TypeError("runtime attestation controls must be booleans")

    def validate(self, spec: OciRecognizerRunSpec) -> None:
        if self.run_spec_id != spec.run_spec_id:
            raise ValueError("runtime attestation binds a different run spec")
        if self.freeze_manifest_id != spec.freeze_manifest_id:
            raise ValueError("runtime attestation binds a different freeze manifest")
        if self.protocol_id != spec.protocol_id:
            raise ValueError("runtime attestation binds a different protocol")
        if self.input_manifest_sha256 != spec.input_manifest_sha256:
            raise ValueError("runtime attestation binds a different input manifest")
        if self.runtime_name != "docker":
            raise ValueError("runtime attestation must name the frozen Docker runtime")
        if self.exit_code != 0 or self.timed_out:
            raise ValueError("untrusted recognizer did not complete successfully")
        if self.output_size_bytes > spec.limits.maximum_output_bytes:
            raise ValueError("untrusted recognizer exceeded its output limit")
        if self.output_size_bytes == 0:
            raise ValueError("untrusted recognizer produced an empty output archive")
        if self.prediction_case_count != spec.expected_case_count:
            raise ValueError("untrusted recognizer did not emit exactly 960 predictions")
        if not all(
            (
                self.observed_network_disabled,
                self.observed_read_only_root,
                self.observed_repository_absent,
                self.observed_answer_manifest_absent,
            )
        ):
            raise ValueError("runtime attestation reports a missing isolation control")


__all__ = (
    "ExternalRuntimeAttestation",
    "FROZEN_RECOGNIZER_ENTRYPOINT",
    "FORBIDDEN_RECOGNIZER_MODULE_PREFIXES",
    "ImageInventoryAudit",
    "OciRecognizerRunSpec",
    "RECOGNIZER_INPUT_MOUNT",
    "RECOGNIZER_OUTPUT_MOUNT",
    "REQUIRED_RECOGNIZER_MODULES",
    "RuntimeLimits",
    "TOTAL_RECOGNIZER_CASE_COUNT",
    "audit_recognizer_image_modules",
    "build_oci_run_spec",
)
