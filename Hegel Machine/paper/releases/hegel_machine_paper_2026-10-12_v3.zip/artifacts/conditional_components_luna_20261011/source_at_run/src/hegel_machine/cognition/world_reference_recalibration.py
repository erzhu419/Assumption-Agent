"""Current-world execution and extension of discovered reference hypotheses.

This is a host integration of the source authors' density-linear and gap-linear
families, their public instrument operations, and the existing relation fitter.
Role binding is a host adapter over the first public object states, not a
model-discovered scientific relation.
It is not an autonomous invention of those families. Export this file unchanged
as an ordinary select_actions program; its JSON contains current-episode state.
Models extend ESTIMATORS with measured-variable bases; the same acquisition,
coefficient fitter, physical controller and outcome analysis execute them.
"""

import json
from pathlib import Path
import re


STATE = Path('shared/reference_recalibration.json')
FAMILIES = (('density', 'densitometer'), ('gap', 'microscope'))
ESTIMATORS = ()


def _basis_features(basis):
    names = []
    for term in basis:
        if term.get('op') == 'feature' and term['name'] not in names:
            names.append(term['name'])
        for name in _basis_features(term.get('children', [])):
            if name not in names:
                names.append(name)
    return names


def _estimators():
    inherited = [{'id': feature, 'features': [feature], 'operations': ['refit']}
                 for feature, _ in FAMILIES]
    return inherited + [{**item, 'features': _basis_features(item['basis'])} for item in ESTIMATORS]


def _save(state):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(state, indent=2))


def _objects(view):
    objects = list(view.get('inventoryObjects', [])) + list(view.get('accessibleEnvironmentObjects', []))
    for group in view.get('nearbyObjects', {}).get('objects', {}).values():
        objects.extend(group)
    return [obj for obj in objects if isinstance(obj, dict) and 'uuid' in obj]


def _view(record):
    return record.get('observation', record)


def _dialog(view):
    text = view.get('dialog_box', {}).get('dialogIn', '')
    match = re.search(r'reactor #(\d+).*?current resonance frequence is:\s*([\d.]+)', text, re.I | re.S)
    return (int(match[1]), float(match[2])) if match else (None, None)


def _installed(objects, crystal, reactor):
    return any(obj['uuid'] == crystal and re.search(
        r'\(in crystal reactor.*?\[uuid:\s*' + str(reactor) + r'\]\)',
        obj.get('description', ''), re.I) for obj in objects)


def _activated(objects, reactor):
    return any(obj['uuid'] == reactor and '(activated)' in obj.get('name', '').lower()
               for obj in objects)


def _scan(observations, current, estimators=None):
    known, crystals, reactors, readings, references = {}, {}, {}, {}, {}
    initial = {}
    for record in observations:
        view = _view(record)
        objects = _objects(view)
        known.update({str(obj['uuid']): obj for obj in objects})
        for obj in objects:
            initial.setdefault(obj['uuid'], obj)
            match = re.search(r'quantum crystal (\d+)', obj.get('name', ''), re.I)
            if match:
                crystals[str(int(match[1]))] = obj['uuid']
        number, frequency = _dialog(view)
        if number is not None:
            action = record.get('action', {})
            reactor = action.get('arg1') if action.get('action') == 'TALK' else reactors.get(str(number))
            if reactor is not None:
                reactors[str(number)] = reactor
                crystal = crystals.get(str(number))
                first = list(initial.values())
                if (_activated(first, reactor) and _installed(first, crystal, reactor)
                        and _activated(objects, reactor) and _installed(objects, crystal, reactor)):
                    references[str(number)] = {'value': frequency, 'evidence': record['index']}
        if record.get('action', {}).get('action') != 'USE' or not record.get('feedback', {}).get('success'):
            continue
        text = view.get('lastActionMessage', '')
        crystal = re.search(r'quantum crystal (\d+)', text, re.I)
        if not crystal:
            continue
        patterns = {'density': r'density.*?approximately\s*([\d.]+)\s*grams',
                    'gap': r'quantum gap.*?be\s*([\d.]+)\s*nm'}
        for feature, pattern in patterns.items():
            match = re.search(pattern, text, re.I | re.S)
            if match:
                readings[feature + '_' + str(int(crystal[1]))] = {
                    'value': float(match[1]), 'evidence': record['index']}
        # All channels are already present in the same public spectrometer use.
        for channel, value in re.findall(r'Channel\s+(\d+):\s*([\d.]+)', text, re.I):
            readings['channel' + channel + '_' + str(int(crystal[1]))] = {
                'value': float(value), 'evidence': record['index']}
        for estimator in ESTIMATORS if estimators is None else estimators:
            for feature, measurement in estimator.get('measurements', {}).items():
                instrument = known.get(str(record['action'].get('arg1')), {})
                if instrument.get('name', '').lower() != measurement['instrument'].lower():
                    continue
                match = re.search(measurement['pattern'], text, re.I | re.S)
                if match:
                    readings[feature + '_' + str(int(crystal[1]))] = {
                        'value': float(match[measurement.get('group', 1)]), 'evidence': record['index']}
    known.update({str(obj['uuid']): obj for obj in _objects(current)})
    for obj in known.values():
        match = re.search(r'quantum crystal (\d+)', obj.get('name', ''), re.I)
        if match:
            crystals[str(int(match[1]))] = obj['uuid']
    return known, crystals, reactors, readings, references


def _action(name, arg1=None, arg2=None):
    action = {'action': name}
    if arg1 is not None:
        action['arg1'] = arg1
    if arg2 is not None:
        action['arg2'] = arg2
    return {'actions': [action]}


def _response_settings(observations, crystals, reactors):
    """Retain measured control responses, without inventing a resonance label."""
    settings = {}
    for record in observations:
        view = _view(record)
        number, frequency = _dialog(view)
        reactor = reactors.get(str(number))
        if reactor is None or not view.get('dialog_box', {}).get('is_in_dialog'):
            continue
        objects = _objects(view)
        positive = _activated(objects, reactor)
        negative = any(obj['uuid'] == reactor and '(uncalibrated)' in obj.get('name', '').lower()
                       for obj in objects)
        if not (positive or negative):
            continue
        for crystal_number, crystal in crystals.items():
            if _installed(objects, crystal, reactor):
                key = (int(crystal_number), reactor, frequency, positive)
                item = settings.setdefault(key, {'crystal': int(crystal_number), 'reactor': reactor,
                    'frequency': frequency, 'activated': positive, 'evidence': []})
                item['evidence'].append(record['index'])
    return list(settings.values())


def refresh_response_evidence(state, observations, current, estimators):
    """Refresh the solver's public inputs after ordinary agent experiments too."""
    _, crystals, reactors, readings, references = _scan(observations, current, estimators)
    state['response_settings'] = _response_settings(observations, crystals, reactors)
    table = state.get('research_table', {})
    for row in table.get('references', []) + table.get('targets', []):
        number = str(row['crystal'])
        row['measurements'].update({key.rsplit('_', 1)[0]: value for key, value in readings.items()
                                    if key.endswith('_' + number)})
        if 'frequency' in row and number in references:
            row['frequency'] = references[number]
        if 'response_settings' in row:
            row['response_settings'] = [item for item in state['response_settings']
                                       if item['crystal'] == row['crystal']]
    grids = _control_grids(observations, state['response_settings'],
                           {row['crystal'] for row in table.get('references', [])})
    state['control_grids'] = grids
    number = next((n for n in state.get('target_numbers', []) if n not in state.get('completed', [])), None)
    if str(number) in grids:
        state['control_grid'] = grids[str(number)]


def _control_grids(observations, responses, reference_ids):
    # Initial reference readouts need not lie on the adjustable control lattice.
    # Learn from actual frequency-changing actions; returning to an initial
    # calibration readout does not overwrite that observed lattice.
    baselines = {}
    for response in responses:
        if response['crystal'] in reference_ids and response['activated']:
            baselines.setdefault(response['crystal'], response['frequency'])
    grids, adjusted_grids, previous_view = {}, {}, {}
    for record in observations:
        view = _view(record)
        number, frequency = _dialog(view)
        dialog = view.get('dialog_box', {})
        steps = [float(match[1]) for label in dialog.get('dialogOptions', {}).values()
                 if (match := re.search(r'frequency by ([\d.]+) hz', label, re.I))]
        bounds = re.search(r'allowable range is ([\d.]+) to ([\d,]+)', dialog.get('dialogIn', ''), re.I)
        if number is not None and steps and bounds:
            step = min(steps)
            grid = {'step': step, 'origin': frequency % step,
                'lower': float(bounds[1]), 'upper': float(bounds[2].replace(',', ''))}
            grids[str(number)] = grid
            choice = record.get('action', {}).get('chosen_dialog_option_int')
            options = previous_view.get('dialog_box', {}).get('dialogOptions', {})
            label = options.get(choice, options.get(str(choice), ''))
            if (_dialog(previous_view)[0] == number and frequency != baselines.get(number)
                    and re.search(r'(increase|decrease) frequency by', label, re.I)):
                adjusted_grids[str(number)] = grid
        previous_view = view
    grids.update(adjusted_grids)
    return grids


def _tune(view, prediction, after_observation=None):
    _, frequency = _dialog(view)
    delta = prediction - frequency
    choices, steps = [], {}
    for key, label in view['dialog_box'].get('dialogOptions', {}).items():
        match = re.search(r'(increase|decrease) frequency by (\d+) hz', label, re.I)
        if match:
            step = int(match[2]) * (1 if match[1].lower() == 'increase' else -1)
            steps[int(key)] = step
            if abs(delta - step) < abs(delta):
                choices.append((abs(delta - step), int(key)))
    if not choices:
        return None
    _, choice = min(choices)
    result = {'actions': [{'chosen_dialog_option_int': choice}]}
    remaining = delta - steps[choice]
    # Schedule the existing physical answer on the final adjustment. Its actual
    # readout, not this planned control step, decides support or refutation.
    if (after_observation and abs(remaining) <= .51
            and not any(abs(remaining - step) < abs(remaining) for step in steps.values())):
        result['after_observation'] = after_observation
    return result


def _prepared_reference_recovery(state, test):
    preparation = test['control_preparation']
    responses = [r for r in state['response_settings'] if r['crystal'] == test['number']]
    grid = preparation['grid']
    positives = [r['frequency'] for r in responses if r['activated'] and
        abs((r['frequency'] - grid['origin']) / grid['step'] -
            round((r['frequency'] - grid['origin']) / grid['step'])) < 1e-6]
    negatives = {r['frequency'] for r in responses if not r['activated']}
    settings = list(dict.fromkeys(sorted(positives, key=lambda f: abs(f - test['restore_frequency']))
        + [f for f in preparation['restore_settings'] if f not in negatives]))
    return {'number': test['number'], 'crystal': test['crystal'], 'reactor': test['reactor'],
        'original_frequency': test['restore_frequency'], 'settings': settings,
        'response_question': test.get('response_question', test['question']),
        'control_preparation': preparation}


def _prepared_reference_step(state, view, observations, questions):
    """Prepare a different control lattice, then restore an actually active reference.

    Boundary saturation and the adjacent recovery points are predictions to test.
    The original fractional setting may cease to be reachable after preparation.
    """
    test = state.get('test')
    if test and test.get('control_preparation'):
        status = questions.get(test['question'], {}).get('status')
        if status in ('supported', 'refuted') or (test.get('tuning_finished') and status == 'inconclusive'):
            state['prepared_recovery'] = _prepared_reference_recovery(state, test)
            state.setdefault('tests', []).append({**test, 'status': status})
            state.pop('test')
            _save(state)
        elif not test.get('preparation_evidence') and view.get('dialog_box', {}).get('is_in_dialog'):
            number, frequency = _dialog(view)
            if number is None:
                return {'stop': 'Cannot read the control after the proposed boundary preparation'}
            if number != test['number']:
                return None
            boundary = test['control_preparation']['boundary']
            grid = test['control_preparation']['grid']
            if abs(frequency - boundary) < 1e-6:
                test['preparation_evidence'] = [observations[-1]['index']]
                _save(state)
            elif not grid['lower'] <= frequency <= grid['upper']:
                return {'stop': 'The proposed bounded control did not saturate as predicted'}
            else:
                choices = []
                for key, label in view['dialog_box'].get('dialogOptions', {}).items():
                    match = re.search(r'(increase|decrease) frequency by (\d+) hz', label, re.I)
                    if match:
                        step = int(match[2]) * (1 if match[1].lower() == 'increase' else -1)
                        predicted = min(grid['upper'], max(grid['lower'], frequency + step))
                        if abs(predicted - boundary) < abs(frequency - boundary):
                            choices.append((abs(predicted - boundary), int(key)))
                if choices:
                    return {'actions': [{'chosen_dialog_option_int': min(choices)[1]}]}
                return {'stop': 'No offered control reaches the proposed preparation boundary'}
    recovery = state.get('prepared_recovery')
    if recovery is None:
        return None
    if not recovery['settings']:
        return {'stop': 'New control lattice has no confirmed reference recovery; retain its failed tests'}
    number, frequency = _dialog(view)
    if not view.get('dialog_box', {}).get('is_in_dialog') or number != recovery['number']:
        if view.get('dialog_box', {}).get('is_in_dialog'):
            return _exit(view)
        accessible = {obj['uuid'] for obj in view.get('accessibleEnvironmentObjects', [])}
        return (_action('TALK', recovery['reactor']) if recovery['reactor'] in accessible
                else _approach(recovery['reactor'], view))
    tuning = _tune(view, recovery['settings'][0])
    if tuning:
        return tuning
    supported = (_installed(_objects(view), recovery['crystal'], recovery['reactor'])
                 and _activated(_objects(view), recovery['reactor']))
    state.setdefault('setting_recoveries', []).append({**recovery,
        'settings': list(recovery['settings']),
        'requested_frequency': recovery['settings'][0], 'actual_frequency': frequency,
        'restored': supported, 'evidence': [observations[-1]['index']]})
    if supported:
        state.pop('prepared_recovery')
    else:
        recovery['settings'].pop(0)
    _save(state)
    return _exit(view)


def _location(public_spec, part):
    names = public_spec.get('capabilities', {}).get('teleport_locations', {})
    name = next((name for name in names if part in name.lower()), None)
    return _action('TELEPORT_TO_LOCATION', name) if name else {'stop': 'No public location for ' + part}


def _approach(uuid, view):
    # TELEPORT_TO_OBJECT uses public IDs and faces its target. If already adjacent
    # but not facing it, the public directional grouping supplies the rotation.
    for direction, objects in view.get('nearbyObjects', {}).get('objects', {}).items():
        if direction in ('north', 'south', 'east', 'west') and any(
                obj.get('uuid') == uuid and obj.get('distance') == 1 for obj in objects):
            return _action('ROTATE_DIRECTION', direction)
    return _action('TELEPORT_TO_OBJECT', uuid)


def _exit(view):
    options = view.get('dialog_box', {}).get('dialogOptions', {})
    option = next(int(key) for key, label in options.items() if str(label).lower() == 'exit')
    return {'actions': [{'chosen_dialog_option_int': option}]}


def bind(public_spec, observations, memory):
    """Supply explicitly cited current rows to the historical finite refitter."""
    return json.loads(STATE.read_text())['binding']


def answer(public_spec, observations, memory):
    state = json.loads(STATE.read_text())
    test = state['test']
    response_feedback = None
    if test.get('response_question') or test.get('authored_experiment'):
        _, crystals, reactors, _, _ = _scan(observations, public_spec['current_observation'])
        state['response_settings'] = _response_settings(observations, crystals, reactors)
        measured = [{**item, 'evidence': [i for i in item['evidence'] if i >= test['started']]}
                    for item in state['response_settings'] if item['crystal'] == test['number']
                    and any(i >= test['started'] for i in item['evidence'])]
        hypotheses = ([] if test.get('authored_experiment') else state['response_research']['hypotheses'])
        refuted = [item['id'] for item in hypotheses if any(
            (item['lower'] <= response['frequency'] -
                item['predictions_by_crystal'][str(test['number'])] <= item['upper'])
                != response['activated'] for response in measured)]
        response_feedback = {'requested_setting': test['prediction'],
            'observed_responses': measured,
            'remaining_hypotheses': [item['id'] for item in hypotheses if item['id'] not in refuted],
            'refuted_hypotheses': refuted,
            'scope': 'Fixed response hypotheses compared with actual intermediate settings; '
                     'a successful intermediate setting does not confirm the requested setting'}
        if test.get('band_revision'):
            revised = test['band_revision']['hypotheses']
            contradicted = [item['id'] for item in revised if any(
                (item['lower'] <= response['frequency'] -
                    item['predictions_by_crystal'][str(test['number'])] <= item['upper'])
                    != response['activated'] for response in measured)]
            response_feedback['band_revision'] = {
                'remaining_hypotheses': [h['id'] for h in revised if h['id'] not in contradicted],
                'refuted_hypotheses': contradicted}
        state['response_feedback'] = response_feedback
        _save(state)
    for record in reversed(observations):
        if record['index'] < test['started']:
            break
        view = _view(record)
        number, frequency = _dialog(view)
        tolerance = 1e-6 if 'restore_frequency' in test or test.get('authored_experiment') else .51
        if number != test['number'] or abs(frequency - test['prediction']) > tolerance:
            continue
        objects = _objects(view)
        if not _installed(objects, test['crystal'], test['reactor']):
            continue
        positive = _activated(objects, test['reactor'])
        negative = any(obj['uuid'] == test['reactor'] and '(uncalibrated)' in obj.get('name', '').lower()
                       for obj in objects)
        if positive or negative:
            return {'status': 'supported' if positive else 'refuted',
                    'answer': {'family': test['family'], 'prediction': test['prediction'],
                               'actual_frequency': frequency, 'activated': positive,
                               'scope': 'This installed crystal at this current fitted prediction',
                               **({'response_feedback': response_feedback} if response_feedback else {})},
                    'evidence': [record['index']]}
    if response_feedback:
        return {'status': 'inconclusive', 'answer': response_feedback,
                'evidence': sorted({i for item in response_feedback['observed_responses']
                                    for i in item['evidence']})}
    return {'status': 'inconclusive', 'answer': 'No installed-crystal physical test at the predicted setting',
            'evidence': []}


def _point_needs_response(state, number):
    """Use acquired target responses after a new target's point failure."""
    if Path('shared/frozen_response_knowledge.json').exists():
        transfer = state.get('response_research', {}).get('frozen_transfer', {})
        if transfer.get('status') not in ('refuted', 'unavailable', 'exhausted'):
            return True
    other_targets = [test for test in state.get('tests', [])
                     if test['number'] != number
                     and test['number'] in state.get('target_numbers', [])
                     and not test.get('authored_experiment')]
    supported = {test['family'] for test in other_targets if test['status'] == 'supported'}
    # Tuning can solve a target without confirming the requested point or
    # naming a winning formula. completed is refreshed from paid responses
    # and current installed/activated observations before this decision.
    completed_target = any(target != number and target in state.get('target_numbers', [])
                           for target in state.get('completed', []))
    response_progress = any(test.get('response_question')
        and 'restore_frequency' not in test
        and (test['status'] == 'supported' or test['number'] in state.get('completed', []))
        for test in other_targets)
    return any(test['number'] == number and test['status'] == 'refuted'
               and not test.get('response_question')
               and not test.get('authored_experiment')
               and (test['family'] in supported or response_progress or completed_target)
               for test in state.get('tests', []))


def _acquire_declared_measurements(readings, measurements, known, crystals, public_spec, view):
    """Use the existing instrument actions before querying a newly declared basis."""
    accessible = {obj['uuid'] for obj in view.get('accessibleEnvironmentObjects', [])}
    inventory = {obj['uuid'] for obj in view.get('inventoryObjects', [])}
    for feature, measurement in measurements.items():
        if all(feature + '_' + str(n) in readings for n in map(int, crystals)):
            continue
        instrument = next((obj['uuid'] for obj in known.values()
                           if obj.get('name', '').lower() == measurement['instrument'].lower()), None)
        if instrument is None:
            return _location(public_spec, 'instruments')
        if instrument not in inventory:
            return _action('PICKUP', instrument) if instrument in accessible else _approach(instrument, view)
        for n in sorted(map(int, crystals)):
            if feature + '_' + str(n) not in readings:
                crystal = crystals[str(n)]
                return (_action('USE', instrument, crystal) if crystal in accessible | inventory
                        else _approach(crystal, view))
    return None


def reference_research_question(number, failure_file, path='shared/consolidated_method.py'):
    """Return an executable revision assignment with the current evidence location."""
    return ('Which shared response premise, measured variable or functional form explains the current crystal '
            + str(number) + ' after the inherited prediction attempts did not complete calibration? Inspect ' + failure_file +
            ' and the current public records. Returned refutations rule out their tested predictions; '
            'use them to revise the next explanation rather than ending the entire search. '
            'Distinguish current-reference fit failures, out-of-range predictions and physical '
            'refutations. Submit a measured-variable/basis hypothesis through run '
            "{operator:'reference_hypothesis',path:" + repr(path) +
            ",hypothesis:{id:YOUR_ID,basis:[PROGRAM_AST,...]}}. "
            'The existing fitter estimates the intercept and basis coefficients from current references; '
            'the existing controller installs, tunes and physically tests targets, returning results here. '
            'Choose the basis and revise it using physical counterexamples. Each distinct basis gets a '
            'new id and is retained in the reusable parent source. Existing measured features and their '
            'actual control responses constrain subsequent research. Declared bases also fit one '
            'observed successful setting per previously solved target. These are operational control '
            'labels, not exact latent resonance values; fit_tolerance is the declared MSE in Hz squared '
            '(default 1e-4). Reusing or fitting a success is not an independent confirmation. '
            'Strict fit failures remain in the numerical record, but approximate bases can still '
            'propose physical tests. Available declared bases are compared by leave-one-crystal-out '
            'error; this is a reuse diagnostic, not a noise estimate or an activation-width model. '
            'Additional measurements may be declared by public instrument name and response pattern. '
            'If the present variables cannot explain the evidence, select a new measurement or return '
            'the specific missing information. The current task_interface describes available research '
            'methods. Current observations and returned answers are in evidence and method_decision; '
            'shared/reference_recalibration.json contains the latest calibration and response state. '
            + failure_file + ' is the historical snapshot that opened this inquiry, not the latest '
            'measurement table. Distinguish an unattempted comparison from an unresolved computation '
            'and an actually refuted explanation. Return what the evidence establishes and what '
            'remains open; a completed control procedure alone does not answer this scientific question.')


def _extend_hypotheses(state, memory, number, path):
    """Return an exhausted scientific search to the existing local researcher."""
    estimator_trial = memory.get('program_arguments', {}).get('estimator_trial', False)
    table = state.get('research_table', {})
    rows = table.get('references', []) + table.get('targets', [])
    features = set.intersection(*(set(row['measurements']) for row in rows)) if rows else set()
    unexpanded = features - set(state.get('expanded_features', []))
    if not estimator_trial and unexpanded and not _point_needs_response(state, number):
        _save(state)
        return {'action': 'run', 'arguments': {'operator': 'reference_expansion', 'path': path}}
    context = {'number': number, 'estimators': list(ESTIMATORS),
        'eligible_targets': [n for n in state.get('target_numbers', [])
                             if n not in state.get('completed', [])
                             and any(row['crystal'] == n for row in rows)],
        'control_grids': state.get('control_grids', {}),
        'responses': [[r['crystal'], r['frequency'], r['activated']]
                      for r in state.get('response_settings', [])],
        'measurements': [[row['crystal'], {key: value['value']
            for key, value in row['measurements'].items()}] for row in rows]}
    response = state.get('response_research', {})
    untried_constraints = (response.get('status') in
        ('no_compatible_response_hypotheses', 'no_untried_supported_setting')
        and 'joint_parameter_search' not in response and state.get('control_grid'))
    # If local fitting exhausts on unchanged observations, archive screening
    # is not a completed family comparison. The full researcher is still owed.
    untried_constraints = untried_constraints or (
        response.get('frozen_transfer', {}).get('research_stage') in
        ('initial_recall', 'withdrawal_recall', 'continuation_recall')
        and response.get('selection') is None)
    if ESTIMATORS and (state.get('response_context') != context or untried_constraints):
        arguments = {'operator': 'reference_response', 'path': path, 'context': context}
        # A returned frozen trial may leave compatible members with no usable
        # experiment. Screen once before enlarging the search; those members
        # stay retained while the parent tries its existing local fits.
        last_test = (state.get('tests') or [{}])[-1]
        returned_trial = (response.get('frozen_transfer', {}).get('status') == 'selected'
            and response.get('question_id')
            and last_test.get('response_question') == response['question_id']
            and response.get('hypotheses'))
        if (Path('shared/frozen_response_knowledge.json').exists()
                and (returned_trial or (not response
                    and not state.get('fit_bindings') and not state.get('tests')))):
            arguments['stage'] = 'frozen_recall'
        return {'action': 'run', 'arguments': arguments}
    if not estimator_trial and response.get('basis_expansion_action'):
        # The existing generator can continue the retained intermediate bases
        # after their raw-coordinate search stalls. Its paid comparison, not
        # another point scan, decides what this finite extension contributes.
        return response['basis_expansion_action']
    remaining = memory['limits']['max_model_calls'] - memory['costs']['model_calls']
    suffix, attempt, returned = str(number), 1, []
    questions = {item['id']: item for item in memory.get('questions', [])}
    question_id = 'reference_extension_' + suffix
    unresolved_return = None
    while memory.get('llm_inquiries', {}).get(question_id, {}).get('invocations', 0):
        question = questions.get(question_id, {})
        fresh_refutation = question.get('status') == 'refuted' and any(
            index >= question.get('opened_before_observation', float('inf'))
            for index in question.get('evidence', []))
        if not fresh_refutation:
            unresolved_return = memory['llm_inquiries'][question_id]
            break
        returned.append({**question,
            'notes': memory['llm_inquiries'][question_id].get('notes', '')})
        attempt += 1
        suffix = str(number) + '_' + str(attempt)
        question_id = 'reference_extension_' + suffix
    parent_resumed = (unresolved_return is not None
        and unresolved_return.get('status') == 'inquiry_finished'
        and questions.get(question_id, {}).get('parent_program_path') == path)
    research = response.get('family_research', {})
    if (not estimator_trial and parent_resumed and memory.get('model_available', True)
            and remaining > 0 and response.get('status') == 'family_research_needed'
            and research.get('selected_role') == 'shared_premise_research'
            and research.get('research_obligation')):
        # A returned author permits the parent to try its experiment, not to
        # ignore a renewed research obligation indefinitely. Reuse completed
        # inquiry returns and paid acquisitions already in this program's log.
        results = memory.get('program_results', [])
        returns = [(i, item['feedback']) for i, item in enumerate(results)
            if item.get('feedback', {}).get('operator') == 'inquire'
            and item['feedback'].get('question', {}).get('id') == question_id]
        # Session status remains inquiry_finished during a resumed invocation.
        # Its return is not logged until it exits, so do not recursively reopen
        # that still-running author on the preceding invocation's evidence.
        if returns and len(returns) == unresolved_return['invocations']:
            returned_at, previous = returns[-1]
            decision = next((step for step in reversed(previous.get('steps', []))
                             if 'model_call' in step), {})
            feedback = decision.get('feedback', {})
            prior_research = feedback.get('response_research', {}).get('family_research', {})
            measured_after_return = any(item.get('feedback', {}).get('observation_indices')
                                        for item in results[returned_at + 1:])
            if (decision.get('action') == 'run'
                    and decision.get('arguments', {}).get('operator') == 'reference_hypothesis'
                    and decision['arguments'].get('path') == path
                    and feedback.get('new_observation_count', 0) > 0
                    and measured_after_return
                    and research.get('response_count', 0) > prior_research.get(
                        'response_count', research.get('response_count', 0))):
                # Continue the same scientific question, notes and history;
                # neither mark it refuted nor replace its original snapshot.
                question = questions[question_id]
                return {'action': 'run', 'arguments': {'operator': 'inquire',
                    'assignment': reference_research_question(number,
                        'shared/reference_extension_' + suffix + '.json', path),
                    'max_model_calls': min(32, remaining), 'question': {
                        key: question[key] for key in (
                            'id', 'question', 'parent_id', 'depends_on', 'parent_program_path')}}}
    selection = response.get('selection')
    fallback = False
    deferred_reason = None
    if not estimator_trial and response.get('status') == 'family_research_needed' and (
            parent_resumed or not memory.get('model_available', True) or remaining <= 0):
        # A returned local researcher leaves the parent free to execute the
        # current experiment. New observations re-enter this same comparison;
        # fresh refutations above still open another research assignment.
        selection = response.get('operational_fallback')
        conditional = response.get('conditional_simplification', {})
        revision_trial = conditional.get('joint_revision', {}).get('experiment')
        failed_revision = revision_trial and any(
            row['crystal'] == revision_trial['number']
            and row['frequency'] == revision_trial['prediction'] and not row['activated']
            for row in state.get('response_settings', []))
        if (failed_revision and conditional.get('status') == 'family_research_needed'
                and not (selection or {}).get('guaranteed_nonlocal_eliminations', 0)):
            # The conditional branch has already compared available controls.
            # A refuted joint revision must not restart member-only exploration
            # merely because the live researcher is unavailable.
            selection = None
            deferred_reason = ('The joint prediction was refuted; the remaining search needs '
                               'a new research decision before further member-only exploration')
        fallback = selection is not None
    experiment = (selection or {}).get('selected_experiment')
    if experiment is not None:
        research = response.get('family_research')
        if research is not None:
            # The operational fallback is selected here, after family assessment.
            # Record the experiment actually sent to the physical controller so
            # its next response participates in the existing progress logic.
            research['selected_test'] = {'crystal': experiment.get('number', number),
                                         'frequency': experiment['prediction']}
            if fallback:
                research['selected_role'] = 'operational_fallback'
            _save(state)
        return {'response_trial': {'family': experiment['family'],
            'prediction': experiment['prediction'],
            'response_question': response['question_id'],
            'response_forecasts': experiment['predictions'],
            **{key: experiment[key] for key in ('number', 'restore_frequency', 'control_preparation')
               if key in experiment},
            'question_id': response['question_id'] + '_physical'}}
    if not estimator_trial and unexpanded:
        _save(state)
        return {'action': 'run', 'arguments': {'operator': 'reference_expansion', 'path': path}}
    if estimator_trial:
        obligation = response.get('family_research', {}).get('research_obligation', {})
        return {'stop': 'Declared estimators need further research after ' +
                response.get('status', 'exhausted prediction trials') + ': ' +
                obligation.get('question', 'no remaining experiment selected from the declared response families') +
                '; return the acquired outcomes to the proposing researcher'}
    if not memory.get('model_available', True) or remaining <= 0:
        return {'stop': deferred_reason or
                'Inherited hypotheses are exhausted; new research needs a live model and remaining calls'}
    if unresolved_return is not None:
        return {'stop': 'Local research returned without a usable extension for this crystal; '
                        'its notebook and rejected predictions remain available'}
    previous = 'shared/reference_before_extension_' + suffix + '.py'
    Path(previous).write_text(Path(path).read_text())
    failure_file = 'shared/reference_extension_' + suffix + '.json'
    failures = [item for item in state.get('tests', []) if item['number'] == number]
    Path(failure_file).write_text(json.dumps({
        'crystal_number': number, 'rejected_families': state['rejected'].get(str(number), []),
        'physical_tests': failures, 'returned_refutations': returned,
        'fit_refutations': [item for item in state.get('fit_refutations', []) if item['number'] == number],
        'out_of_range_predictions': state.get('out_of_range', []),
        'prediction_selection': state.get('prediction_selection'),
        'research_table': state.get('research_table', {}), 'estimators': list(ESTIMATORS),
        'family_research': response.get('family_research'),
        'operational_fallback': response.get('operational_fallback'),
        'prior_program': previous, 'current_program': path}, indent=2))
    _save(state)
    return {'action': 'run', 'arguments': {'operator': 'inquire',
        'max_model_calls': min(32, remaining), 'question': {
            'id': question_id, 'parent_id': 'task', 'depends_on': [],
            'question': reference_research_question(number, failure_file, path)}}}


def _response_trial_lost_support(state, test, question):
    """Return a frozen member trial to research after intermediate refutation.

    Family-level experiments can remain useful beyond their finite witnesses.
    Explicit experiments and reference restoration retain their existing scope.
    """
    response = state.get('response_research', {})
    if (test.get('authored_experiment') or 'restore_frequency' in test
            or test.get('control_preparation')
            or test.get('number') not in state.get('target_numbers', [])
            or question.get('status') != 'inconclusive'
            or not test.get('response_question')
            or test['response_question'] != response.get('question_id')
            or (response.get('selection') or {}).get('consequence_scope')
                != 'frozen_numeric_response_members'):
        return False
    feedback = question.get('answer') or {}
    if (feedback.get('requested_setting') != test['prediction']
            or not feedback.get('observed_responses')
            or 'remaining_hypotheses' not in feedback):
        return False
    supporters = {key for key, positive in test.get('response_forecasts', {}).items() if positive}
    return bool(supporters) and supporters.isdisjoint(feedback['remaining_hypotheses'])


def select_actions(public_spec, observations, memory):
    state = json.loads(STATE.read_text()) if STATE.exists() else {'completed': [], 'rejected': {}}
    view = public_spec['current_observation']
    known, crystals, reactors, readings, references = _scan(observations, view)
    responses = _response_settings(observations, crystals, reactors)
    state['response_settings'] = responses
    state['control_grids'] = _control_grids(observations, responses, set(map(int, references)))
    accessible = {obj['uuid'] for obj in view.get('accessibleEnvironmentObjects', [])}
    inventory = {obj['uuid'] for obj in view.get('inventoryObjects', [])}
    path = memory['program_path']
    questions = {item['id']: item for item in memory.get('questions', [])}
    authored = memory.get('program_arguments', {}).get('response_experiment')
    test = state.get('test')
    prepared_step = _prepared_reference_step(state, view, observations, questions)
    if prepared_step is not None:
        return prepared_step
    lost_support = bool(test) and _response_trial_lost_support(
        state, test, questions.get(test['question'], {}))
    if lost_support:
        revision = test.get('band_revision')
        active = (_installed(_objects(view), test['crystal'], test['reactor'])
                  and _activated(_objects(view), test['reactor']))
        if revision is None and not active:
            _save(state)
            return {'action': 'run', 'arguments': {'operator': 'reference_response',
                'path': path, 'stage': 'pending_band_revision'}}
        if revision and not active:
            feedback = questions[test['question']]['answer'].get('band_revision')
            remaining = (feedback['remaining_hypotheses'] if feedback is not None
                         else [h['id'] for h in revision['hypotheses']])
            lost_support = not bool(set(remaining) & set(revision['positive_supporters']))
    if test and (questions.get(test['question'], {}).get('status') in ('supported', 'refuted')
                 or (test.get('tuning_finished')
                     and questions.get(test['question'], {}).get('status') == 'inconclusive')
                 or lost_support):
        status = questions[test['question']]['status']
        if lost_support:
            question = questions[test['question']]
            test['retirement'] = {
                'reason': 'intermediate_responses_refuted_all_requested_members',
                'evidence': question['evidence'],
                'remaining_hypotheses': question['answer']['remaining_hypotheses'],
                'requested_supporters': [key for key, positive in test['response_forecasts'].items() if positive]}
        if 'restore_frequency' in test:
            state['recovery'] = {'number': test['number'], 'frequency': test['restore_frequency'],
                'crystal': test['crystal'], 'reactor': test['reactor'],
                'response_question': test.get('response_question', test['question'])}
        elif status == 'supported':
            state['completed'].append(test['number'])
            if not test.get('authored_experiment'):
                state['survivor'] = test['family']
        elif not test.get('authored_experiment') and not lost_support:
            # Retire this family's point-fit branch. Response research below
            # can still test other coefficient/window hypotheses in that basis.
            state['rejected'].setdefault(str(test['number']), []).append(test['family'])
        state.setdefault('tests', []).append({**test, 'status': status})
        state.pop('test')
        _save(state)
        test = None
    recovery = state.get('recovery')
    if recovery and (not view.get('dialog_box', {}).get('is_in_dialog')
                     or _dialog(view)[0] != recovery['number']):
        if view.get('dialog_box', {}).get('is_in_dialog'):
            return _exit(view)
        return (_action('TALK', recovery['reactor']) if recovery['reactor'] in accessible
                else _approach(recovery['reactor'], view))
    if view.get('dialog_box', {}).get('is_in_dialog'):
        number, frequency = _dialog(view)
        if test and number == test['number']:
            analysis = [{'action': 'evaluate', 'arguments': {
                'path': path, 'question_id': test['question']}}]
            tuning = _tune(view, test['prediction'], after_observation=analysis)
            if tuning:
                if test.get('response_question') or test.get('authored_experiment'):
                    tuning['after_observation'] = analysis
                return tuning
            if 'restore_frequency' in test or test.get('authored_experiment'):
                test['tuning_finished'] = True
                _save(state)
            result = _exit(view)
            result['after_observation'] = [{'action': 'evaluate', 'arguments': {
                'path': path, 'question_id': test['question']}}]
            return result
        recovery = state.get('recovery')
        if recovery and number == recovery['number']:
            tuning = _tune(view, recovery['frequency'])
            if tuning:
                return tuning
            supported = (_installed(_objects(view), recovery['crystal'], recovery['reactor'])
                         and _activated(_objects(view), recovery['reactor']))
            state.setdefault('setting_recoveries', []).append({**recovery,
                'actual_frequency': frequency,
                'restored': supported, 'evidence': [observations[-1]['index']]})
            if supported:
                state.pop('recovery')
            _save(state)
            if not supported:
                return {'stop': 'Previously successful setting did not restore activation; revise its conditions'}
        return _exit(view)

    if authored:
        if any(item['question'] == authored['question_id'] for item in state.get('tests', [])):
            return {'stop': 'Requested response experiment finished; return its observed answer to the researcher'}
        number = authored['number']
        selected = {'family': 'authored_setting', 'prediction': authored['setting'],
                    'question_id': authored['question_id'], 'authored_experiment': True,
                    'parent_id': authored['parent_id'],
                    **{key: authored[key] for key in ('research_question', 'response_comparison') if key in authored}}
        if authored.get('control_preparation'):
            selected['control_preparation'] = authored['control_preparation']
        if str(number) in references:
            selected['restore_frequency'] = references[str(number)]['value']
        return _trial_action(state, selected, number, crystals, reactors, view, observations, test)

    # Reacquire instrument handles and reference roles from this world only.
    for feature, name in FAMILIES:
        instrument = next((obj['uuid'] for obj in known.values() if obj.get('name', '').lower() == name), None)
        if instrument is None:
            return _location(public_spec, 'instruments')
        if instrument not in inventory:
            return _action('PICKUP', instrument) if instrument in accessible else _approach(instrument, view)
    reactor = next((obj['uuid'] for obj in known.values()
        if 'crystal reactor' in obj.get('name', '').lower() and obj['uuid'] not in reactors.values()), None)
    if reactor is not None:
        return _action('TALK', reactor) if reactor in accessible else _approach(reactor, view)
    if len(reactors) < len(crystals) or not reactors:
        return _location(public_spec, 'reactor')
    if set(crystals) != set(reactors):
        return _location(public_spec, 'crystal bench')
    if len(references) < 2:
        return {'stop': 'Current public records lack two initially activated installed references'}
    if 'reference_numbers' not in state:
        state['reference_numbers'] = sorted(map(int, references))
        state['target_numbers'] = sorted(int(n) for n in crystals if n not in references)
        _save(state)
    for feature, name in FAMILIES:
        instrument = next(obj['uuid'] for obj in known.values() if obj.get('name', '').lower() == name)
        for number in sorted(map(int, crystals)):
            if feature + '_' + str(number) not in readings:
                crystal = crystals[str(number)]
                return (_action('USE', instrument, crystal) if crystal in accessible | inventory
                        else _approach(crystal, view))

    successful = {}
    for response in sorted(responses, key=lambda item: item['evidence'][-1]):
        if response['activated']:
            successful[response['crystal']] = response
    if not test:
        state['completed'] = [n for n in state['target_numbers'] if n in successful
            and _installed(list(known.values()), crystals[str(n)], reactors[str(n)])
            and _activated(list(known.values()), reactors[str(n)])]
    state['research_table'] = {'references': [], 'targets': []}
    for n in sorted(map(int, crystals)):
        values = {key.rsplit('_', 1)[0]: value for key, value in readings.items()
                  if key.endswith('_' + str(n))}
        row = {'crystal': n, 'measurements': values}
        if n in state['reference_numbers']:
            row['frequency'] = references[str(n)]
            state['research_table']['references'].append(row)
        else:
            row['response_settings'] = [item for item in responses if item['crystal'] == n]
            state['research_table']['targets'].append(row)
    _save(state)
    number = next((n for n in state['target_numbers'] if n not in state['completed']), None)
    if number is None:
        return {'stop': 'All current targets have physically observed activation support'}
    if not test and number in successful:
        setting = successful[number]
        crystal, reactor = crystals[str(number)], reactors[str(number)]
        if not _installed(_objects(view), crystal, reactor):
            if crystal not in inventory:
                return _action('PICKUP', crystal) if crystal in accessible else _approach(crystal, view)
            return _action('PUT', crystal, reactor) if reactor in accessible else _approach(reactor, view)
        if reactor not in accessible:
            return _approach(reactor, view)
        state['recovery'] = {'number': number, 'frequency': setting['frequency'],
            'crystal': crystal, 'reactor': reactor, 'source_evidence': setting['evidence']}
        _save(state)
        return _action('TALK', reactor)
    estimators = _estimators()
    measurements = {feature: measurement for estimator in estimators
                    for feature, measurement in estimator.get('measurements', {}).items()}
    estimators.sort(key=lambda item: item['id'] != state.get('survivor'))
    trials, selected = [], None
    # A submitted estimator must reach the existing fit/physical trial before
    # an older point failure routes the parent back to response research.
    # Rejected candidates and paid counterexamples still filter that trial.
    if (not memory.get('program_arguments', {}).get('estimator_trial', False)
            and _point_needs_response(state, number)):
        acquire = _acquire_declared_measurements(readings, measurements, known, crystals, public_spec, view)
        if acquire:
            return acquire
        extension = _extend_hypotheses(state, memory, number, path)
        selected = extension.get('response_trial')
        if selected is None:
            return extension
    for estimator in (() if selected is not None else estimators):
        family, features = estimator['id'], estimator['features']
        paid_check = state.get('family_history_checks', {}).get(family, {})
        if (paid_check.get('status') == 'UNSAT_VERIFIED'
                and paid_check.get('basis') == estimator.get('basis')
                and all(readings.get(feature + '_' + number, {}).get('value') == value
                        for number, values in paid_check.get('features', {}).items()
                        for feature, value in values.items())):
            # This exclusion concerns the shared response family under the
            # recorded measurements. Changed bindings reopen the candidate.
            continue
        if family in state['rejected'].get(str(number), []):
            fit_only = ('basis' in estimator and any(item['number'] == number and item['family'] == family
                for item in state.get('fit_refutations', [])) and not any(
                    item.get('number') == number and item.get('family') == family
                    for key in ('tests', 'response_constraints', 'out_of_range')
                    for item in state.get(key, [])))
            if not fit_only:
                continue
            # The strict fit remains rejected. Its shape can still propose an
            # approximate control prediction whose success needs a real trial.
            state['rejected'][str(number)].remove(family)
        # A later declaration can supply the acquisition for an earlier basis
        # using the same feature. Acquire only the current candidate's readings.
        acquire = _acquire_declared_measurements(readings,
            {feature: measurements[feature] for feature in features if feature in measurements},
            known, crystals, public_spec, view)
        if acquire:
            return acquire
        qid = 'reference_fit_' + family + '_' + str(number)
        fitted = memory.get('relation_research', {}).get(qid)
        rows = [{'features': {feature: readings[feature + '_' + str(n)]['value'] for feature in features},
                     'target': references[str(n)]['value'],
                     'evidence': sorted({references[str(n)]['evidence'],
                         *[readings[feature + '_' + str(n)]['evidence'] for feature in features]})}
                for n in state['reference_numbers']]
        if 'basis' in estimator:
            for n in state['target_numbers']:
                if n == number or n not in successful:
                    continue
                setting = successful[n]
                rows.append({'features': {feature: readings[feature + '_' + str(n)]['value'] for feature in features},
                    'target': setting['frequency'], 'target_kind': 'observed_successful_setting',
                    'crystal': n, 'evidence': sorted({setting['evidence'][-1],
                        *[readings[feature + '_' + str(n)]['evidence'] for feature in features]})})
        prior_rows = state.get('fit_bindings', {}).get(qid, (fitted or {}).get('fit_rows', rows))
        if (fitted is None or prior_rows != rows
                or ('basis' in estimator and 'empirical_prediction' not in fitted)):
            state.setdefault('fit_bindings', {})[qid] = rows
            state['binding'] = {'rows': rows, 'operations': estimator.get('operations', ['refit']),
                'tolerance': estimator.get('fit_tolerance', 1e-4),
                'probes': [{'id': 'current_crystal_' + str(number),
                    'features': {feature: readings[feature + '_' + str(number)]['value'] for feature in features},
                    'actions': [{'action': 'TALK', 'arg1': reactors[str(number)]}]}]}
            if 'basis' in estimator:
                state['binding']['basis'] = estimator['basis']
                state['binding']['prediction_objective'] = 'operational_setting'
            _save(state)
            return {'action': 'run', 'arguments': {'operator': 'research_update', 'path': path,
                'question': {'id': qid, 'question': 'Fit the ' + family +
                             ' hypothesis to current activated references; predict current crystal ' + str(number),
                             'parent_id': 'task', 'depends_on': []}}}
        predictions = (fitted.get('selected_probe') or {}).get('predictions', [])
        empirical = fitted.get('empirical_prediction') if 'basis' in estimator else None
        if empirical:
            predictions = [item['prediction'] for item in empirical['probe_predictions']]
        if predictions:
            measured = [item for item in responses if item['crystal'] == number
                        and abs(item['frequency'] - predictions[0]) < .5]
            if measured:
                response = max(measured, key=lambda item: item['evidence'][-1])
                if not response['activated']:
                    state['rejected'].setdefault(str(number), []).append(family)
                    state.setdefault('response_constraints', []).append({'number': number, 'family': family,
                        'prediction': predictions[0], 'setting': response['frequency'],
                        'status': 'refuted', 'evidence': response['evidence'], 'fit_question': qid})
                    _save(state)
                    continue
            if not 0 <= predictions[0] <= 10000:
                state['rejected'].setdefault(str(number), []).append(family)
                state.setdefault('out_of_range', []).append({'number': number, 'family': family,
                    'prediction': predictions[0], 'allowed_range': [0, 10000], 'fit_question': qid})
                _save(state)
                continue
            proposal = {'family': family, 'prediction': predictions[0], 'fit_question': qid}
            if empirical:
                proposal.update(fit_mse=empirical['fit_mse'],
                    leave_one_out_mse=empirical['leave_one_out_mse'],
                    fit_status=('within_tolerance' if empirical['fit_mse'] <= estimator.get('fit_tolerance', 1e-4)
                                else 'approximate'), numerical_question_status=fitted['status'])
                trials.append(proposal)
                continue
            selected = proposal
            break
        if fitted.get('status') != 'refuted':
            return {'stop': 'Current reference fit has no unique numerical prediction: ' + fitted['diagnosis']}
        state['rejected'].setdefault(str(number), []).append(family)
        state.setdefault('fit_refutations', []).append({'number': number, 'family': family,
            'fit_question': qid, 'diagnosis': fitted['diagnosis'], 'evidence': fitted['evidence']})
        _save(state)
    if selected is None and trials:
        selected = min(trials, key=lambda item: (
            item['leave_one_out_mse'] if item['leave_one_out_mse'] is not None else float('inf'),
            item['fit_mse']))
        state['prediction_selection'] = {'number': number, 'selected_family': selected['family'],
            'criterion': 'leave_one_crystal_out_mse', 'candidates': trials,
            'scope': 'Prediction trials ordered by reused calibration evidence; '
                     'not fresh confirmation, a noise estimate or a known activation-range contrast'}
        _save(state)
    if selected is None:
        extension = _extend_hypotheses(state, memory, number, path)
        selected = extension.get('response_trial')
        if selected is None:
            return extension
    return _trial_action(state, selected, number, crystals, reactors, view, observations, test)


def _trial_action(state, selected, number, crystals, reactors, view, observations, test):
    accessible = {obj['uuid'] for obj in view.get('accessibleEnvironmentObjects', [])}
    inventory = {obj['uuid'] for obj in view.get('inventoryObjects', [])}
    family, prediction = selected['family'], selected['prediction']
    number = selected.get('number', number)
    crystal, reactor = crystals[str(number)], reactors[str(number)]
    if not _installed(_objects(view), crystal, reactor):
        if crystal not in inventory:
            return _action('PICKUP', crystal) if crystal in accessible else _approach(crystal, view)
        return _action('PUT', crystal, reactor) if reactor in accessible else _approach(reactor, view)
    if reactor not in accessible:
        return _approach(reactor, view)
    if not test:
        state['test'] = {'number': number, 'family': family, 'prediction': prediction,
            'started': len(observations), 'crystal': crystal, 'reactor': reactor,
            'question': selected.get('question_id', 'reference_test_' + str(number) + '_' + family),
            **{key: selected[key] for key in ('fit_mse', 'fit_status', 'leave_one_out_mse',
                'response_question', 'response_forecasts', 'restore_frequency', 'authored_experiment',
                'parent_id', 'research_question', 'response_comparison') if key in selected}}
        if selected.get('control_preparation'):
            state['test']['control_preparation'] = selected['control_preparation']
        _save(state)
    result = _action('TALK', reactor)
    result['question'] = state['test'].get('research_question') or {
        'id': state['test']['question'], 'question':
        'Does the installed current crystal activate at the current ' + family + ' prediction?',
        'parent_id': state['test'].get('parent_id', state['test'].get('response_question', 'task')), 'depends_on': []}
    return result
